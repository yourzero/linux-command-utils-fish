complete -c q -f
complete -c q -n '__fish_is_first_token' -a '(__q_category_slugs)' -d 'category'
complete -c q -n '__fish_is_first_token' -a '-h' -d 'show usage'
