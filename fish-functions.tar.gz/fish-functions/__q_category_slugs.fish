function __q_category_slugs --description 'Internal: list category slugs, one per line (used for tab-completion)'
    for line in (__q_category_data)
        echo (string split '|' -- $line)[1]
    end
end
