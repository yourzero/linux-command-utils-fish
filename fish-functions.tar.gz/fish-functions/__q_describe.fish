function __q_describe --description 'Internal: print the --description text of a q-function, by name'
    set -l fdir (dirname (status --current-filename))
    set -l f "$fdir/$argv[1].fish"
    test -f "$f"; or return 1
    set -l m (string match -r -- '--description\s+[\x27"](.*)[\x27"]' < $f)
    test -n "$m[2]"; or return 1
    echo $m[2]
end
