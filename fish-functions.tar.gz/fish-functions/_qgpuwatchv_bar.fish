function _qgpuwatchv_bar --description 'Render a colored percentage bar (helper for qgpuwatchv)'
    set -l label $argv[1]
    set -l pct $argv[2]
    set -l width $argv[3]

    set -l filled (math -s0 "$pct * $width / 100")
    if test $filled -lt 0
        set filled 0
    end
    if test $filled -gt $width
        set filled $width
    end
    set -l empty (math $width - $filled)

    if test $pct -ge 85
        set_color red
    else if test $pct -ge 60
        set_color yellow
    else
        set_color green
    end

    printf "      %s [" $label
    printf "%s" (string repeat -n $filled "█")
    set_color brblack
    printf "%s" (string repeat -n $empty "░")
    set_color normal
    printf "] %3s%%\n" $pct
end
