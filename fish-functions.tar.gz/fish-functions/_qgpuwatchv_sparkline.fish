function _qgpuwatchv_sparkline --description 'Render a unicode sparkline from a list of 0-100 values (helper for qgpuwatchv)'
    set -l label $argv[1]
    set -l values $argv[2..-1]
    set -l blocks ▁ ▂ ▃ ▄ ▅ ▆ ▇ █
    set -l line ""

    for v in $values
        set -l i (math -s0 "$v * 7 / 100")
        if test $i -lt 0
            set i 0
        end
        if test $i -gt 7
            set i 7
        end
        set -l idx (math $i + 1)
        set line "$line$blocks[$idx]"
    end

    printf "      %s %s\n" $label $line
end
