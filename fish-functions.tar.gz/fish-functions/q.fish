function q --description 'Quick lookup: show q-commands in a category (tab-complete category names)'
    if test "$argv[1]" = "-h"
        echo "Usage: q <category>"
        echo "  Shows all q-commands in a category, e.g.: q docker"
        echo "  Tab-complete the category name, or run 'q' with no arguments to list them."
        return
    end

    if test (count $argv) -eq 0
        echo "Available categories:"
        for line in (__q_category_data)
            set -l parts (string split '|' -- $line)
            printf "  %-10s %s\n" $parts[1] $parts[2]
        end
        echo
        echo "Usage: q <category>   e.g. q docker"
        return
    end

    set -l query (string lower -- (string join ' ' -- $argv))
    set -l match_display ''
    set -l match_members

    # 1) exact or prefix match on the category slug
    for line in (__q_category_data)
        set -l parts (string split '|' -- $line)
        if test "$parts[1]" = "$query"; or string match -q -- "$query*" -- $parts[1]
            set match_display $parts[2]
            set match_members $parts[3]
            break
        end
    end

    # 2) substring match on slug or display name
    if test -z "$match_display"
        for line in (__q_category_data)
            set -l parts (string split '|' -- $line)
            if string match -qi -- "*$query*" $parts[1]; or string match -qi -- "*$query*" $parts[2]
                set match_display $parts[2]
                set match_members $parts[3]
                break
            end
        end
    end

    # 3) fallback: query matches one of the commands themselves — show its category
    if test -z "$match_display"
        for line in (__q_category_data)
            set -l parts (string split '|' -- $line)
            for m in (string split ' ' -- $parts[3])
                if string match -qi -- "*$query*" $m
                    set match_display $parts[2]
                    set match_members $parts[3]
                    break
                end
            end
            test -n "$match_display"; and break
        end
    end

    if test -z "$match_display"
        echo "No category or command matches '$argv[1]'."
        echo
        echo "Available categories:"
        for line in (__q_category_data)
            echo "  "(string split '|' -- $line)[1]
        end
        return 1
    end

    echo "─── $match_display ───"
    echo
    for fname in (string split ' ' -- $match_members)
        set -l d (__q_describe $fname)
        printf "  %-14s %s\n" $fname $d
    end
end
