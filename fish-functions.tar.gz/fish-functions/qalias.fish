function qalias --description 'List all defined aliases/abbreviations'
    echo "─── Defined Abbreviations ──────────────────────────────"
    abbr --list | sort
    echo
    echo "─── Defined Functions (non-builtin) ────────────────────"
    functions | tr ',' '\n' | sort
end
