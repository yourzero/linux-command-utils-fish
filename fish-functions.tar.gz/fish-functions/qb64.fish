function qb64 --description 'Base64 encode/decode a string'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qb64 <string>       -> encode"
        echo "       qb64 -d <string>   -> decode"
        return
    end
    if test "$argv[1]" = "-d"
        echo $argv[2] | base64 -d
    else
        echo $argv[1] | base64
    end
end
