function qbig --description 'N largest files in a directory tree'
    if test "$argv[1]" = "-h"
        echo "Usage: qbig [path] [n]"
        echo "  Find N largest files under path. Default: current dir, top 20."
        return
    end
    set -l path $argv[1]
    set -l count $argv[2]
    test -z "$path"; and set path .
    test -z "$count"; and set count 20
    find $path -type f -exec du -h {} + 2>/dev/null | sort -rh | head -$count
end
