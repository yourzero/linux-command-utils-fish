function qcheatsheet --description 'Auto-generated list of every function and its description'
    if test "$argv[1]" = "-h"
        echo "Usage: qcheatsheet [filter]"
        echo "  Lists every function in ~/.config/fish/functions/ with its description."
        echo "  Reads the --description string set on each function definition."
        echo "  Optional filter narrows results (e.g. qcheatsheet git)"
        return
    end

    set -l filter $argv[1]
    set -l fdir (dirname (status --current-filename))

    if not test -d "$fdir"
        echo "Could not locate function directory to scan."
        return 1
    end

    echo "─── Command Cheatsheet ($fdir) ────────────"
    echo

    set -l count 0
    for f in $fdir/*.fish
        set -l fname (basename $f .fish)
        # Pull the --description string directly out of the function line
        set -l desc (string match -r -- '--description\s+[\x27"](.*)[\x27"]' < $f)
        if test -n "$desc[2]"
            set -l d $desc[2]
            if test -z "$filter"; or string match -qi "*$filter*" -- "$fname $d"
                printf "  %-14s %s\n" $fname $d
                set count (math $count + 1)
            end
        end
    end

    echo
    echo "  Total: $count functions shown. Run any with -h for usage."
end
