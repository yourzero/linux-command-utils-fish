function qcheatsheet --description 'Auto-generated list of every function and its description, grouped by category'
    if test "$argv[1]" = "-h"
        echo "Usage: qcheatsheet [filter]"
        echo "  Lists every function in ~/.config/fish/functions/, grouped by category (as in the README)."
        echo "  Reads the --description string set on each function definition."
        echo "  Optional filter narrows results (e.g. qcheatsheet git)"
        return
    end

    set -l filter $argv[1]
    set -l fdir (dirname (status --current-filename))

    if not test -d "$fdir"
        echo "Could not locate function directory to scan."
        return 1
    end

    echo "─── Command Cheatsheet ($fdir) ────────────"

    set -l seen
    set -l total 0

    for line in (__q_category_data)
        set -l parts (string split '|' -- $line)
        set -l category $parts[2]
        set -l members (string split ' ' -- $parts[3])
        set -l header_printed 0

        for fname in $members
            set -a seen $fname
            set -l f "$fdir/$fname.fish"
            test -f "$f"; or continue
            set -l d (__q_describe $fname)
            test -n "$d"; or continue
            if test -n "$filter"; and not string match -qi "*$filter*" -- "$category $fname $d"
                continue
            end
            if test $header_printed -eq 0
                echo
                echo "  $category"
                echo "  "(string repeat -n (string length -- "$category") "─")
                set header_printed 1
            end
            printf "    %-14s %s\n" $fname $d
            set total (math $total + 1)
        end
    end

    # Anything not in the category map (e.g. new/custom functions) still shows up here.
    set -l header_printed 0
    for f in $fdir/q*.fish
        set -l fname (basename $f .fish)
        contains -- $fname $seen; and continue
        set -l d (__q_describe $fname)
        test -n "$d"; or continue
        if test -n "$filter"; and not string match -qi "*$filter*" -- "Uncategorized $fname $d"
            continue
        end
        if test $header_printed -eq 0
            echo
            echo "  Uncategorized"
            echo "  ─────────────"
            set header_printed 1
        end
        printf "    %-14s %s\n" $fname $d
        set total (math $total + 1)
    end

    echo
    echo "  Total: $total functions shown. Run any with -h for usage."
end
