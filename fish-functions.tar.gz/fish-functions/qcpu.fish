function qcpu --description 'CPU model, cores, current load'
    echo "─── CPU Info ───────────────────────────────────────────"
    grep -m1 "model name" /proc/cpuinfo | sed 's/model name\s*:\s*/  Model:  /'
    echo "  Cores:  "(nproc)
    echo "  Load:   "(cat /proc/loadavg | awk '{print $1, $2, $3, "(1m 5m 15m)"}')
    echo
    echo "─── CPU Frequency ──────────────────────────────────────"
    if test -f /proc/cpuinfo
        grep "cpu MHz" /proc/cpuinfo | awk '{ sum += $4; count++ } END { printf "  Average: %.0f MHz\n", sum/count }'
    end
end
