function qdclean --description 'Remove stopped containers, dangling images, unused networks'
    echo "─── Docker Cleanup ─────────────────────────────────────"
    read -P "Remove stopped containers, dangling images, unused networks? [y/N] " confirm
    if test "$confirm" = "y"; or test "$confirm" = "Y"
        docker system prune -f
    else
        echo "Aborted."
    end
end
