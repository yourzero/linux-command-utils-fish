function qdf --description 'Disk free, human-readable, sorted by usage, no tmpfs noise'
    if test "$argv[1]" = "-h"
        echo "Usage: qdf [path]"
        echo "  Human-readable df, filtered/sorted. Default path = /"
        return
    end
    set -l target $argv[1]
    if test -z "$target"
        set target /
    end
    df -h --output=source,size,used,avail,pcent,target $target \
        | grep -v tmpfs \
        | grep -v devtmpfs \
        | grep -v udev \
        | column -t
end
