function qdlogs --description 'Tail container logs (last 100 + follow)'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qdlogs <container_name>"
        return
    end
    docker logs --tail 100 -f $argv[1]
end
