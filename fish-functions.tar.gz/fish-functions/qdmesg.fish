function qdmesg --description 'dmesg warnings and errors, with timestamps'
    echo "─── dmesg Warnings + Errors ────────────────────────────"
    dmesg --level=warn,err --ctime 2>/dev/null | tail -40; or dmesg | grep -iE "warn|error|fail|critical" | tail -40
end
