function qdnet --description 'Show Docker networks'
    echo "─── Docker Networks ────────────────────────────────────"
    docker network ls --format "table {{.Name}}\t{{.Driver}}\t{{.Scope}}" 2>/dev/null
end
