function qdns --description 'Show A/AAAA/MX/NS/TXT records for a hostname'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qdns <hostname>"
        echo "  Show A, AAAA, MX, NS, and TXT records for hostname."
        return
    end
    set -l host $argv[1]
    echo "─── DNS Records: $host ─────────────────────────────────"
    for type in A AAAA MX NS TXT
        echo
        echo "[ $type ]"
        dig +short $type $host 2>/dev/null; or echo "  (none)"
    end
end
