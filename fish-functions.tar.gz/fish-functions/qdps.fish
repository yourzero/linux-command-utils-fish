function qdps --description 'Running containers, clean format'
    echo "─── Running Containers ─────────────────────────────────"
    docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}" 2>/dev/null; or echo "Docker not running or not installed."
end
