function qdpsall --description 'All containers including stopped'
    echo "─── All Containers (incl. stopped) ─────────────────────"
    docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.ID}}" 2>/dev/null
end
