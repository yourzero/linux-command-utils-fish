function qdsh --description 'Shell into a running container'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qdsh <container_name> [shell]"
        echo "  Default shell: bash. Fallback: sh."
        return
    end
    set -l shell $argv[2]
    test -z "$shell"; and set shell bash
    docker exec -it $argv[1] $shell 2>/dev/null; or docker exec -it $argv[1] sh
end
