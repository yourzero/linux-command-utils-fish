function qdubig --description 'Find the biggest files/dirs anywhere under a path'
    if test "$argv[1]" = "-h"
        echo "Usage: qdubig [path] [n]"
        echo "  Find top N largest items under path. Default: / , top 20."
        return
    end
    set -l target $argv[1]
    set -l count $argv[2]
    test -z "$target"; and set target /
    test -z "$count"; and set count 20
    du -ah $target 2>/dev/null | sort -rh | head -$count
end
