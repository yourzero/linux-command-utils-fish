function qduh --description 'du summary, human-readable, sorted largest-first'
    if test "$argv[1]" = "-h"
        echo "Usage: qduh [path] [depth]"
        echo "  Summarize disk usage sorted by size. Default: current dir, depth 1."
        return
    end
    set -l target $argv[1]
    set -l depth $argv[2]
    test -z "$target"; and set target .
    test -z "$depth"; and set depth 1
    du -h --max-depth=$depth $target 2>/dev/null | sort -rh | head -30
end
