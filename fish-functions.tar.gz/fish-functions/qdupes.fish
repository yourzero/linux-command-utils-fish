function qdupes --description 'Find duplicate files by MD5 checksum'
    if test "$argv[1]" = "-h"
        echo "Usage: qdupes [path]"
        echo "  Find duplicate files by MD5 checksum. Warning: slow on large trees."
        return
    end
    set -l path $argv[1]
    test -z "$path"; and set path .
    echo "─── Scanning for duplicate files under: $path ──────────"
    find $path -type f 2>/dev/null | xargs md5sum 2>/dev/null | sort | uniq -w32 -d
end
