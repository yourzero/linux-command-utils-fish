function qenv --description 'Environment variables, sorted, filterable'
    if test -n "$argv[1]"
        env | grep -i $argv[1] | sort
    else
        env | sort
    end
end
