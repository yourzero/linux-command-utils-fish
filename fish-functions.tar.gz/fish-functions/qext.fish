function qext --description 'List unique file extensions with counts'
    if test "$argv[1]" = "-h"
        echo "Usage: qext [path]"
        echo "  List all unique file extensions with counts."
        return
    end
    set -l path $argv[1]
    test -z "$path"; and set path .
    find $path -type f 2>/dev/null | sed 's/.*\.//' | sort | uniq -c | sort -rn | head -30
end
