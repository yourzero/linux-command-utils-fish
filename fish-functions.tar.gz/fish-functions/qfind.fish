function qfind --description 'Find files by name pattern, no permission noise'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qfind <pattern> [path]"
        echo "  Find files matching pattern, suppress permission errors."
        return
    end
    set -l pattern $argv[1]
    set -l path $argv[2]
    test -z "$path"; and set path .
    find $path -name $pattern 2>/dev/null
end
