function qgbr --description 'Branches with last commit date and author'
    echo "─── Branches ───────────────────────────────────────────"
    git branch -v --sort=-committerdate 2>/dev/null | head -20; or echo "Not a git repo."
end
