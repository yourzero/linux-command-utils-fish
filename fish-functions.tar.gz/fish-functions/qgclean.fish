function qgclean --description 'Remove untracked files/dirs (with confirmation)'
    echo "─── Untracked Files to Remove ──────────────────────────"
    git clean -nd 2>/dev/null
    echo
    read -P "Remove these? [y/N] " confirm
    if test "$confirm" = "y"; or test "$confirm" = "Y"
        git clean -fd
    else
        echo "Aborted."
    end
end
