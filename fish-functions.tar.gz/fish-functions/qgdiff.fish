function qgdiff --description 'Staged + unstaged diff summary'
    echo "─── Staged Changes ─────────────────────────────────────"
    git diff --cached --stat 2>/dev/null
    echo
    echo "─── Unstaged Changes ───────────────────────────────────"
    git diff --stat 2>/dev/null
end
