function qglog --description 'Pretty git log with author and date'
    set -l count $argv[1]
    test -z "$count"; and set count 20
    git log --pretty=format:'%C(yellow)%h%Creset  %C(cyan)%ad%Creset  %C(green)%an%Creset  %s' --date=short -$count 2>/dev/null; or echo "Not a git repo."
end
