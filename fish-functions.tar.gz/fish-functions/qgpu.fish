function qgpu --description 'GPU temp, load, VRAM, power'
    if not command -q nvidia-smi
        echo "nvidia-smi not found."
        return 1
    end
    echo "─── GPU Status ─────────────────────────────────────────"
    nvidia-smi \
        --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw,power.limit \
        --format=csv,noheader,nounits \
        | awk -F', ' '{
            printf "  Model:       %s\n", $1
            printf "  Temp:        %s°C\n", $2
            printf "  GPU Load:    %s%%\n", $3
            printf "  VRAM:        %s / %s MiB\n", $4, $5
            printf "  Power:       %sW / %sW\n", $6, $7
        }'
end
