function qgpuproc --description 'Show what processes are using the GPU'
    echo "─── GPU Processes ──────────────────────────────────────"
    nvidia-smi --query-compute-apps=pid,name,used_memory --format=csv,noheader 2>/dev/null \
        | awk -F', ' '{ printf "  PID: %-8s  MiB: %-8s  %s\n", $1, $3, $2 }'; or echo "  No GPU compute processes found."
end
