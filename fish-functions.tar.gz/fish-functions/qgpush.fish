function qgpush --description 'Stage all + commit + push in one shot'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qgpush <commit message>"
        echo "  Stages all changes, commits, and pushes to current branch."
        return
    end
    git add -A; and git commit -m "$argv"; and git push
end
