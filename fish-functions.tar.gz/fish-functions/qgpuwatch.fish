function qgpuwatch --description 'Live GPU stats every 2 seconds (Ctrl+C to exit)'
    if not command -q nvidia-smi
        echo "nvidia-smi not found."
        return 1
    end
    watch -n 2 "nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw \
        --format=csv,noheader,nounits \
        | awk -F', ' '{
            printf \"  %-35s  %s°C  GPU:%s%%  VRAM:%s/%s MiB  Power:%sW\n\", \$1, \$2, \$3, \$4, \$5, \$6
        }'"
end
