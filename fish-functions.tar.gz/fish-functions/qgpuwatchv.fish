function qgpuwatchv --description 'Visual live GPU dashboard: bars + sparklines, updates every 2s (Ctrl+C to exit)'
    if not command -q nvidia-smi
        echo "nvidia-smi not found."
        return 1
    end

    set -l interval 2
    set -l hist_len 120

    function _qgpuwatchv_cleanup --on-signal INT
        tput cnorm
        echo
        functions -e _qgpuwatchv_cleanup
    end

    tput civis
    while true
        set -l out (nvidia-smi --query-gpu=index,name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw,power.limit \
            --format=csv,noheader,nounits)

        set -l cols (tput cols)
        set -l bar_width 36
        if test $cols -lt 70
            set bar_width 18
        end
        set -l spark_width (math -s0 "max(10, $cols - 16)")

        clear
        set_color --bold cyan
        echo "  ⚡ GPU Watch  —  "(date "+%H:%M:%S")"   (Ctrl+C to exit)"
        set_color normal
        echo

        for line in $out
            set -l f (string split ", " -- $line)
            set -l idx $f[1]
            set -l name $f[2]
            set -l temp $f[3]
            set -l util $f[4]
            set -l vram_used $f[5]
            set -l vram_total $f[6]
            set -l power $f[7]
            set -l power_limit $f[8]

            set -l vram_pct (math -s0 "$vram_used / $vram_total * 100")
            set -l power_pct 0
            if test "$power_limit" != "" -a "$power_limit" != "[N/A]"
                set power_pct (math -s0 "$power / $power_limit * 100")
            end

            # rolling history, kept in indirect global vars per GPU index
            set -l hu_var "_qgpuwatchv_h_util_$idx"
            set -l hv_var "_qgpuwatchv_h_vram_$idx"
            set -l h_util $$hu_var
            set -l h_vram $$hv_var
            set -a h_util $util
            set -a h_vram $vram_pct
            if test (count $h_util) -gt $hist_len
                set -l neg_hist (math -- -$hist_len)
                set h_util $h_util[$neg_hist..-1]
            end
            if test (count $h_vram) -gt $hist_len
                set -l neg_hist (math -- -$hist_len)
                set h_vram $h_vram[$neg_hist..-1]
            end
            set -g $hu_var $h_util
            set -g $hv_var $h_vram

            set_color --bold white
            printf "  [%s] %s\n" $idx $name
            set_color normal

            if test $temp -ge 80
                set_color red
            else if test $temp -ge 65
                set_color yellow
            else
                set_color green
            end
            printf "      Temp: %s°C" $temp
            set_color normal
            printf "   Power: %sW" $power
            if test "$power_limit" != "" -a "$power_limit" != "[N/A]"
                printf " / %sW (%s%%)" $power_limit $power_pct
            end
            printf "\n"

            _qgpuwatchv_bar "GPU " $util $bar_width
            _qgpuwatchv_bar "VRAM" $vram_pct $bar_width
            printf "        %s / %s MiB\n" $vram_used $vram_total

            set -l n_util (count $h_util)
            set -l show_util $h_util
            if test $n_util -gt $spark_width
                set -l neg_spark (math -- -$spark_width)
                set show_util $h_util[$neg_spark..-1]
            end
            set -l n_vram (count $h_vram)
            set -l show_vram $h_vram
            if test $n_vram -gt $spark_width
                set -l neg_spark (math -- -$spark_width)
                set show_vram $h_vram[$neg_spark..-1]
            end
            _qgpuwatchv_sparkline "GPU util" $show_util
            _qgpuwatchv_sparkline "VRAM %  " $show_vram
            echo
        end

        sleep $interval
    end
end
