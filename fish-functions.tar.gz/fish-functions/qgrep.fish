function qgrep --description 'Recursive grep, case-insensitive, with color'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qgrep <pattern> [path]"
        echo "  Recursive grep, case-insensitive, with color."
        return
    end
    set -l pattern $argv[1]
    set -l path $argv[2]
    test -z "$path"; and set path .
    grep -rniI --color=auto $pattern $path 2>/dev/null
end
