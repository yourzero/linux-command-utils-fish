function qgst --description 'Git status + recent log in one view'
    echo "─── Git Status ─────────────────────────────────────────"
    git status -sb 2>/dev/null; or echo "Not a git repo."
    echo
    echo "─── Recent Commits ─────────────────────────────────────"
    git log --oneline --graph --decorate -10 2>/dev/null
end
