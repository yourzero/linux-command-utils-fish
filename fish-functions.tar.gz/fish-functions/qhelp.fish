function qhelp --description 'Static formatted reference card (manually curated, grouped by category)'
    echo "
╔══════════════════════════════════════════════════════════════╗
║         fish-functions  –  Quick Command Reference           ║
╠══════════════════════════════════════════════════════════════╣
║  DISK & STORAGE                                              ║
║  qdf        Disk free (clean, sorted, no tmpfs noise)        ║
║  qduh       du summary sorted by size                        ║
║  qdubig     Find N biggest files/dirs under a path           ║
║  qmount     Clean mounted filesystem list                     ║
║                                                              ║
║  NETWORKING                                                  ║
║  qip        Real IPs only (no loopback, link-local, docker)  ║
║  qip6       Real IPv6 addresses                              ║
║  qpubip     Your public internet-facing IP                   ║
║  qroute     Default gateway + routing table                  ║
║  qport      Listening ports (optional: filter by port)       ║
║  qportall   All active TCP connections                        ║
║  qdns       A/AAAA/MX/NS/TXT records for a hostname          ║
║  qping      Ping with 5 packets                              ║
║  qtrace     Traceroute (uses mtr if available)               ║
║  qmac       MAC addresses for real interfaces                ║
║  qwifi      Current WiFi SSID and signal                     ║
║                                                              ║
║  PROCESSES & HEALTH                                          ║
║  qtop       Top 15 processes by CPU                          ║
║  qtopmem    Top 15 processes by RAM                          ║
║  qkill      Find + kill process by name (with confirm)       ║
║  qmem       Memory and swap summary                          ║
║  qcpu       CPU model, cores, load                           ║
║  quptime    Uptime + load average                            ║
║  qtemp      CPU/GPU temperatures                             ║
║  qwho       Who's logged in                                  ║
║  qopenfiles Top 10 open file descriptor counts               ║
║                                                              ║
║  LOGS                                                        ║
║  qlog       systemd journal: errors + warnings               ║
║  qlogf      Live follow journal for a unit                   ║
║  qlasterr   Errors from this boot                            ║
║  qdmesg     dmesg warnings and errors                        ║
║                                                              ║
║  FILES & SEARCH                                              ║
║  qfind      find by name, no permission noise                ║
║  qgrep      Recursive grep, case-insensitive                 ║
║  qrecent    Files modified in last N minutes                 ║
║  qbig       N largest files in a directory tree              ║
║  qext       Unique file extension counts                     ║
║  qdupes     Find duplicate files by checksum                 ║
║                                                              ║
║  GIT                                                         ║
║  qgst       git status + recent log                          ║
║  qglog      Pretty git log with author/date                  ║
║  qgdiff     Staged + unstaged diff summary                   ║
║  qgclean    Remove untracked files (with confirm)            ║
║  qgbr       Branches with last commit date                   ║
║  qgpush     Stage all + commit + push in one shot             ║
║                                                              ║
║  DOCKER                                                      ║
║  qdps       Running containers (clean format)                ║
║  qdpsall    All containers including stopped                 ║
║  qdlogs     Tail container logs (follow mode)                ║
║  qdclean    Remove stopped containers + dangling images      ║
║  qdstats    Live resource usage for all containers           ║
║  qdsh       Shell into a running container                   ║
║  qdnet      Docker networks                                  ║
║                                                              ║
║  SERVICES                                                    ║
║  qsvc       Status of a systemd service                      ║
║  qsvcs      All failed services                              ║
║  qsvca      All active (running) services                    ║
║                                                              ║
║  PACKAGES (apt)                                              ║
║  qpkg       Check if package installed / search              ║
║  qupdate    apt update + prompt upgrade                      ║
║                                                              ║
║  NVIDIA GPU                                                  ║
║  qgpu       GPU temp, load, VRAM, power                      ║
║  qgpuwatch  Live GPU stats every 2 seconds                   ║
║  qgpuproc   Processes using the GPU                          ║
║                                                              ║
║  vLLM                                                        ║
║  qvllm      Check vLLM server + loaded model                 ║
║  qvllmlog   Tail vLLM service logs                           ║
║                                                              ║
║  SSH                                                         ║
║  qsshkeys   List SSH key fingerprints                        ║
║  qsshagent  Load private keys into ssh-agent                 ║
║                                                              ║
║  MISC                                                        ║
║  qenv       Environment variables (filterable)               ║
║  qpath      PATH entries, one per line                       ║
║  qhist      Search command history                           ║
║  qalias     List abbreviations + defined functions           ║
║  qtime      Time any command                                 ║
║  qb64       Base64 encode/decode                             ║
║  qjson      Pretty-print JSON                                ║
║  qwhat      which + man summary for a command                ║
║  qsum       SHA256 checksum of a file                        ║
║  qwatch     watch wrapper with interval                      ║
║  qcheatsheet  Auto-generated list, parsed from source files  ║
║  qhelp      This help menu                                   ║
╚══════════════════════════════════════════════════════════════╝

  All commands support:  <cmd> -h   for usage help.
  Set \$VLLM_HOST / \$VLLM_PORT to override vLLM defaults.
"
end
