function qhist --description 'Search command history for pattern'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qhist <pattern>"
        echo "  Search command history for pattern."
        return
    end
    history | grep -i $argv[1] | tail -30
end
