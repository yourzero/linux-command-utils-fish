function qip --description 'Show real IPs only (skip loopback, link-local, docker/veth noise)'
    if test "$argv[1]" = "-h"
        echo "Usage: qip"
        echo "  Show interface names and their real IPv4 addresses."
        echo "  Skips loopback (127.x), link-local (169.254.x), and virtual interfaces."
        return
    end
    echo "─── Network Interfaces (real IPs only) ────────────────"
    ip -4 addr show | awk '
        /^[0-9]+:/ { iface = $2; gsub(/:/, "", iface) }
        /inet / {
            ip = $2
            if (ip !~ /^127\./ && ip !~ /^169\.254\./) {
                printf "  %-20s %s\n", iface, ip
            }
        }
    '
end
