function qip6 --description 'Show real IPv6 addresses, skip loopback and link-local'
    echo "─── Network Interfaces (IPv6, real only) ───────────────"
    ip -6 addr show | awk '
        /^[0-9]+:/ { iface = $2; gsub(/:/, "", iface) }
        /inet6 / {
            ip = $2
            if (ip !~ /^::1/ && ip !~ /^fe80/) {
                printf "  %-20s %s\n", iface, ip
            }
        }
    '
end
