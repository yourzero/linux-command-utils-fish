function qjson --description 'Pretty-print JSON from a file or stdin'
    if test -f "$argv[1]"
        python3 -m json.tool $argv[1]
    else
        python3 -m json.tool
    end
end
