function qkill --description 'Find and kill a process by name (with confirmation)'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qkill <process_name>"
        echo "  Find and kill processes matching name. Shows matches first."
        return
    end
    echo "─── Matching Processes ─────────────────────────────────"
    pgrep -la $argv[1]
    echo
    read -P "Kill all matching '$argv[1]'? [y/N] " confirm
    if test "$confirm" = "y"; or test "$confirm" = "Y"
        pkill -f $argv[1]; and echo "Done."; or echo "No matching process found."
    else
        echo "Aborted."
    end
end
