function qlasterr --description "Show last boot's errors only"
    echo "─── Errors from This Boot ──────────────────────────────"
    journalctl -b -p err --no-pager | tail -50
end
