function qlog --description 'Tail systemd journal (errors + warnings), optional unit filter'
    if test "$argv[1]" = "-h"
        echo "Usage: qlog [unit_name]"
        echo "  Tail systemd journal (errors + warnings). Optionally filter by unit."
        return
    end
    if test -n "$argv[1]"
        journalctl -u $argv[1] -n 50 --no-pager -p warning
    else
        journalctl -n 100 --no-pager -p warning
    end
end
