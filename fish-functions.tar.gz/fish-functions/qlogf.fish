function qlogf --description 'Live follow systemd journal for a unit'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qlogf <unit_name>"
        echo "  Live follow systemd journal for a unit (like tail -f syslog)."
        return
    end
    journalctl -u $argv[1] -f
end
