function qmac --description 'Show MAC addresses for real interfaces'
    echo "─── MAC Addresses ──────────────────────────────────────"
    ip link show | awk '
        /^[0-9]+:/ { iface = $2; gsub(/:/, "", iface) }
        /link\/ether/ { printf "  %-20s %s\n", iface, $2 }
    '
end
