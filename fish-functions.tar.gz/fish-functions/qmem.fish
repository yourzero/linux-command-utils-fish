function qmem --description 'Memory and swap usage summary'
    echo "─── Memory Usage ───────────────────────────────────────"
    free -h | column -t
    echo
    echo "─── Swap Usage ─────────────────────────────────────────"
    swapon --show 2>/dev/null; or echo "  No swap configured."
end
