function qmount --description 'Show mounted filesystems in a clean table, skip pseudo-mounts'
    echo "─── Mounted Filesystems ───────────────────────────────"
    mount | grep -v "proc\|sysfs\|devtmpfs\|securityfs\|cgroup\|tmpfs\|devpts\|mqueue\|hugetlbfs\|debugfs\|fusectl" | column -t
end
