function qopenfiles --description 'Count open file descriptors by process (top 10)'
    echo "─── Top 10 Open File Descriptors by Process ────────────"
    lsof 2>/dev/null | awk 'NR>1 { print $1 }' | sort | uniq -c | sort -rn | head -10 | awk '{ printf "  %-8s %s\n", $1, $2 }'
end
