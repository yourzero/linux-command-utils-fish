function qpath --description 'PATH entries, one per line'
    echo "─── PATH entries ───────────────────────────────────────"
    for i in (seq (count $PATH))
        echo "$i: $PATH[$i]"
    end
end
