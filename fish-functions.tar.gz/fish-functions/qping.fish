function qping --description 'Ping a host with 5 packets'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qping <host>"
        return
    end
    ping -c 5 $argv[1]
end
