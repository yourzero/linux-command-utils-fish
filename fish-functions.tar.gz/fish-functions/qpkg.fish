function qpkg --description 'Check if a package is installed, or search'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qpkg <package_name>"
        echo "  Check if package is installed, or search available packages."
        return
    end
    dpkg -l "*$argv[1]*" 2>/dev/null | grep -E "^ii"; or echo "Not installed. Searching available..."
    apt-cache search $argv[1] 2>/dev/null | head -10
end
