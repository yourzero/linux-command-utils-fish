function qport --description 'Show listening ports, optionally filter by port number'
    if test "$argv[1]" = "-h"
        echo "Usage: qport [port_number]"
        echo "  Show all listening ports, or filter by port number."
        return
    end
    if test -n "$argv[1]"
        ss -tlnp | grep ":$argv[1]"
    else
        echo "─── Listening Ports ────────────────────────────────────"
        ss -tlnp | column -t
    end
end
