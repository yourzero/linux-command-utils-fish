function qportall --description 'All active TCP connections, clean view'
    echo "─── All Active TCP Connections ─────────────────────────"
    ss -tnp | column -t
end
