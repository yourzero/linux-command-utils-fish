function qpubip --description 'Get your public IP (external, internet-facing)'
    echo -n "Public IP: "
    curl -s --max-time 5 https://ifconfig.me 2>/dev/null; or \
    curl -s --max-time 5 https://api.ipify.org 2>/dev/null; or \
    echo "(failed to fetch)"
    echo
end
