function qrecent --description 'Files modified in last N minutes'
    if test "$argv[1]" = "-h"
        echo "Usage: qrecent [path] [minutes]"
        echo "  Show files modified in last N minutes. Default: current dir, 60 min."
        return
    end
    set -l path $argv[1]
    set -l mins $argv[2]
    test -z "$path"; and set path .
    test -z "$mins"; and set mins 60
    find $path -type f -mmin -$mins 2>/dev/null | sort
end
