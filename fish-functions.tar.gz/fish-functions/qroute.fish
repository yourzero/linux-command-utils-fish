function qroute --description 'Show default gateway and routing table cleanly'
    echo "─── Default Route / Gateway ────────────────────────────"
    ip route show default
    echo
    echo "─── Full Routing Table ─────────────────────────────────"
    ip route show
end
