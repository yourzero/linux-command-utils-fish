function qsshagent --description 'Load all private keys into ssh-agent'
    echo "─── SSH Agent Keys ─────────────────────────────────────"
    if not ssh-add -l &>/dev/null
        eval (ssh-agent -c)
    end
    for key in ~/.ssh/id_*
        if test (string match -r '\.pub$' $key)
            continue
        end
        test -f $key; and ssh-add $key 2>/dev/null
    end
    ssh-add -l
end
