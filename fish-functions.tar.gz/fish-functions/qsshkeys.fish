function qsshkeys --description 'List SSH key fingerprints'
    echo "─── SSH Keys (~/.ssh/) ─────────────────────────────────"
    for key in ~/.ssh/*.pub
        test -f $key; and ssh-keygen -lf $key 2>/dev/null
    end
end
