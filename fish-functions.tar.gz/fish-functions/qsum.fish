function qsum --description 'SHA256 checksum of a file'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qsum <file>"
        return
    end
    sha256sum $argv[1]
end
