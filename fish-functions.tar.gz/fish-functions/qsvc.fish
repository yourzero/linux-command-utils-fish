function qsvc --description 'Show status of a service cleanly'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qsvc <service_name>"
        return
    end
    systemctl status $argv[1] --no-pager | head -20
end
