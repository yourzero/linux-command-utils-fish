function qsvca --description 'List all active (running) services'
    echo "─── Active Services ────────────────────────────────────"
    systemctl list-units --type=service --state=running --no-pager
end
