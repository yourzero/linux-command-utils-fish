function qsvcs --description 'List all failed services'
    echo "─── Failed Services ────────────────────────────────────"
    systemctl list-units --state=failed --no-pager
end
