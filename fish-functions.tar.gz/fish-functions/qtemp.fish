function qtemp --description 'CPU/GPU temperatures (lm-sensors + nvidia-smi)'
    echo "─── Temperatures ───────────────────────────────────────"
    if command -q sensors
        sensors 2>/dev/null | grep -E "Core|Tctl|Tdie|temp|°C" | grep -v '^[[:space:]]*$'
    else
        echo "  lm-sensors not installed (sudo apt install lm-sensors)"
    end
    echo
    if command -q nvidia-smi
        echo "─── GPU (nvidia-smi) ───────────────────────────────────"
        nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total \
            --format=csv,noheader,nounits \
            | awk -F', ' '{ printf "  %-35s %s°C  GPU:%s%%  VRAM:%s/%s MiB\n", $1, $2, $3, $4, $5 }'
    end
end
