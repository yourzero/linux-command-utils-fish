function qtime --description 'Time a command and report elapsed time clearly'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qtime <command> [args...]"
        return
    end
    set -l start (date +%s%N)
    $argv
    set -l end (date +%s%N)
    set -l ms (math --scale=0 "($end - $start) / 1000000")
    echo
    echo "─── Elapsed: $ms"ms" ────────────────────────────────────"
end
