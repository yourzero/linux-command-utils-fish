function qtop --description 'Top 15 processes by CPU, clean output'
    echo "─── Top 15 Processes by CPU ────────────────────────────"
    ps aux --sort=-%cpu | awk 'NR==1 || NR<=16' | awk '{ printf "%-10s %-6s %-6s %-6s %s\n", $1, $2, $3, $4, $11 }' | column -t
end
