function qtopmem --description 'Top 15 processes by RAM'
    echo "─── Top 15 Processes by Memory ─────────────────────────"
    ps aux --sort=-%mem | awk 'NR==1 || NR<=16' | awk '{ printf "%-10s %-6s %-6s %-6s %s\n", $1, $2, $3, $4, $11 }' | column -t
end
