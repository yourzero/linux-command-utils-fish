function qtrace --description 'Traceroute using the fastest available tool'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qtrace <host>"
        return
    end
    if command -q traceroute
        traceroute $argv[1]
    else if command -q mtr
        mtr --report $argv[1]
    else
        echo "Neither traceroute nor mtr is installed."
    end
end
