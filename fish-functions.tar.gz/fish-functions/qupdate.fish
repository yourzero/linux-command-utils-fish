function qupdate --description 'apt update + prompt before upgrade'
    echo "─── Updating package lists ─────────────────────────────"
    sudo apt update
    echo
    echo "─── Upgradable packages ────────────────────────────────"
    apt list --upgradable 2>/dev/null | grep -v "Listing"
    echo
    read -P "Run upgrade now? [y/N] " confirm
    if test "$confirm" = "y"; or test "$confirm" = "Y"
        sudo apt upgrade -y
    else
        echo "Update list refreshed. Upgrade skipped."
    end
end
