function quptime --description 'Uptime and load average, human-readable'
    uptime -p
    echo "  Load: "(cat /proc/loadavg)
end
