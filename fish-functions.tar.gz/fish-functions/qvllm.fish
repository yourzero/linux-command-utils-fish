function qvllm --description 'Check vLLM server and loaded model'
    set -l host $VLLM_HOST
    set -l port $VLLM_PORT
    test -z "$host"; and set host localhost
    test -z "$port"; and set port 8000
    echo "─── vLLM Status ($host:$port) ──────────────────────────"
    curl -s --max-time 5 "http://$host:$port/v1/models" | python3 -m json.tool 2>/dev/null; or echo "  vLLM server not responding at $host:$port"
end
