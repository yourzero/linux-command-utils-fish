function qvllmlog --description 'Tail the vLLM systemd service log (if run as a service)'
    if systemctl is-active vllm &>/dev/null
        journalctl -u vllm -f
    else
        echo "vLLM service not found. Try: qdlogs vllm  (if running in Docker)"
    end
end
