function qwatch --description 'watch wrapper with interval'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qwatch <interval_seconds> <command...>"
        echo "  Example: qwatch 5 qgpu"
        return
    end
    set -l interval $argv[1]
    set -e argv[1]
    watch -n $interval $argv
end
