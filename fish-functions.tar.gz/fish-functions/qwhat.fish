function qwhat --description 'which + man summary for a command'
    if test -z "$argv[1]"; or test "$argv[1]" = "-h"
        echo "Usage: qwhat <command>"
        return
    end
    echo "─── Location ───────────────────────────────────────────"
    which $argv[1] 2>/dev/null; or echo "  Not found in PATH"
    echo
    echo "─── Description ────────────────────────────────────────"
    man $argv[1] 2>/dev/null | head -20; or whatis $argv[1] 2>/dev/null; or echo "  No man page found."
end
