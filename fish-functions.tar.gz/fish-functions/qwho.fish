function qwho --description "Who's logged in and what are they doing"
    echo "─── Logged-in Users ────────────────────────────────────"
    w
end
