function qwifi --description 'Show current WiFi SSID and signal strength'
    echo "─── WiFi Status ────────────────────────────────────────"
    if command -q nmcli
        nmcli -f DEVICE,SSID,SIGNAL,SECURITY device wifi list 2>/dev/null | head -10
    else if command -q iwgetid
        iwgetid
    else
        echo "No WiFi tools found (nmcli or iwgetid required)."
    end
end
